// NightClub.java

package nightclubsimulation;
import javax.swing.*;
import java.awt.Point;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Timer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import static nightclubsimulation.NightClubGUI.femalePositions;
import static nightclubsimulation.NightClubGUI.malePositions;

public class NightClub {

    public void setMalePopulation(int malePopulation) {
        this.malePopulation = malePopulation;
    }

    public void setFemalePopulation(int femalePopulation) {
        this.femalePopulation = femalePopulation;
    }
    public static String str1;
    public static int male;
    public static int female;
    public static int bouncer;
    private int malePopulation;
    private int femalePopulation;
    private int bouncerPopulation;
    private Pathfinding pathfinding;
    private int simulationSteps;

    private NightClubGUI gui;

    private volatile boolean simulationPaused;

    public NightClub(Properties config) {


        this.malePopulation = Integer.parseInt(config.getProperty("initialMalePopulation"));
        this.femalePopulation = Integer.parseInt(config.getProperty("initialFemalePopulation"));
        this.bouncerPopulation = Integer.parseInt(config.getProperty("initialBouncerPopulation"));
        this.pathfinding = new Pathfinding();
        this.simulationSteps = Integer.parseInt(config.getProperty("simulationSteps"));
        SwingUtilities.invokeLater(() -> gui = new NightClubGUI(this));

    }

    private void updateGUI() {
        // Use SwingUtilities.invokeLater() to update the GUI components
        SwingUtilities.invokeLater(() -> {
            // Update the labels or other components with the current population information
            gui.updatePopulationLabels();
        });
    }

    public int getMalePopulation() {
        return malePopulation;
    }

    public int getFemalePopulation() {
        return femalePopulation;
    }

    public int getBouncerPopulation() {
        return bouncerPopulation;
    }

    public void startSimulation() {
        simulationPaused = false;

        ExecutorService executor = Executors.newSingleThreadExecutor();


        System.out.println("Current Population - Males: " + malePopulation +
                ", Females: " + femalePopulation + ", Bouncers: " + bouncerPopulation);

        List<Point> malePositions = generateRandomPositions(malePopulation);
        List<Point> femalePositions = generateRandomPositions(femalePopulation);

        male = getMalePopulation();
        female = getFemalePopulation();
        bouncer = getBouncerPopulation();

        executor.execute(() -> {
        for (int i = 0; i < 5; i++) {

            if (simulationPaused) {
                break;
            }

            if(malePopulation == 0 || femalePopulation ==0){
                System.out.println("\nThere are no more girls or males are in the Club\n");
                break;
            }
            Point malePosition = malePositions.get(i);
            Point femalePosition = femalePositions.get(i);

            final int index = i;

            // Update the GUI after each simulation step

            try {
                Thread.sleep(1000); // Adjust the delay as needed
            } catch (InterruptedException e) {
                e.printStackTrace();
            }


            System.out.println("\nMale M" + index + " trying to approach a girl");
            str1 = "Male M" + index + " trying to approach a girl";

            System.out.println("Male M" + index + " successfully approached a girl!");

            str1 = str1.concat("\nMale M" + index + " successfully approached a girl!");

            // Assuming here that male is attempting to leave with two girls
            System.out.println("Male M" + index + " trying to hit 1 girl");

            str1 = str1.concat("\nMale M" + index + " trying to hit 1 girl");

            updatePositions();

            if (malesLeaveWithGirls()) {
                 System.out.println("Male M" + index +
                        " Successfully hits and leave with 1 girl\n");

                str1 = str1.concat("\nMale M" + index + " Successfully hits and leave with 1 girl\n");
                malePopulation -= 1;
                femalePopulation -= 1;

                System.out.println("Current Population - Males: " + malePopulation +
                        ", Females: " + femalePopulation + ", Bouncers: " + bouncerPopulation);

                if(malePopulation != femalePopulation){
                    bouncerKickOut();
                }

            }
            else {
                System.out.println("Male M" + index + " failed to approach a girl. Drinking more alcohol...");
                drinkAlcohol();

                str1 = str1.concat("\nMale M" + index + " failed to hits a girl. Drinking more alcohol...");

                if(femalePopulation <2){
                    System.out.println("The Bouncer is kicking out the male because there is only 1 Girl in the Club");

                    malePopulation -= 1;

                    str1 = str1.concat("\nThe Bouncer is kicking out the male because there is only 1 Girl in the Club");

                }
                else{

                // Retry the approach with 2 girls
                System.out.println("Male M" + index + " trying to hit 2 girls");
                str1 = str1.concat("\nMale M" + index + " trying to hit 2 girls");
                if (malesLeaveWithGirls()) {
                    System.out.println("Male M" + index +
                            " Successfully hits and leave with 2 girl\n");

                    str1 = str1.concat("\nMale M" + index + " Successfully hits and leave with 2 girl");
                    malePopulation -= 1;
                    femalePopulation -= 2;

                    System.out.println("Current Population - Males: " + malePopulation +
                            ", Females: " + femalePopulation + ", Bouncers: " + bouncerPopulation);

                    if(malePopulation != femalePopulation){
                        bouncerKickOut();
                    }
                }
                else{
                    System.out.println("Male M" + index +
                            "Failed to hit 2 girls and is Kicking out of the Club");

                    str1 = str1.concat("\nMale M" + index + "Failed to hit 2 girls and is Kicking out of the Club");
                    malePopulation -= 1;

                    System.out.println("Current Population - Males: " + malePopulation +
                            ", Females: " + femalePopulation + ", Bouncers: " + bouncerPopulation);

                    if(malePopulation != femalePopulation){
                        bouncerKickOut();
                    }
                }

                }
            }
            updateGUI();

            try {
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }

            male = getMalePopulation();
            female = getFemalePopulation();
            bouncer = getBouncerPopulation();
        }

        // Move the bouncerKickOut() method outside of the for loop
        // to ensure it is called after all male-female interactions
        bouncerKickOut();

        // Additional print statements for clarity
        System.out.println("After males leave with girls and bouncer kicks out excess males:");
        System.out.println("Current Population - Males: " + malePopulation +
                ", Females: " + femalePopulation + ", Bouncers: " + bouncerPopulation);

        updateGUI();

            executor.shutdown();
        });

    }

    public void pauseSimulation() {
        simulationPaused = true;
        System.out.println("Simulation paused");
    }

    public void resetSimulation() {
        // Add logic to reset simulation if needed
        // You can reset variables, clear data, etc.
        // For simplicity, we'll just print a message
        System.out.println("Simulation reset");
    }

    private boolean malesLeaveWithGirls() {
        return Math.random() < 0.6;
    }

    private void bouncerKickOut() {
        int excessMales = Math.max(0, malePopulation - femalePopulation);

        if (excessMales > 0) {
            int malesToKickOut = Math.min(excessMales, bouncerPopulation);

            malePopulation -= malesToKickOut;
            System.out.println("Bouncer kicked out " + malesToKickOut + " males. Remaining males: " +
                    malePopulation + ", females: " + femalePopulation);
        }
    }

    private void drinkAlcohol() {
        // For simplicity, increase intoxication level by a fixed amount
        // You can modify this based on your simulation requirements
        for (int i = 0; i < malePopulation; i++) {
            // Increase intoxication level (adjust the value based on your simulation)
            // Intoxication level should be limited to a certain threshold
        }
    }

    private List<Point> generateRandomPositions(int count) {
        List<Point> positions = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            int x = (int) (Math.random() * 800);
            int y = (int) (Math.random() * 600);
            positions.add(new Point(x, y));
        }
        return positions;
    }

    private boolean maleApproachFemale(Point malePosition, Point femalePosition) {
        // For simplicity, consider the approach successful with an 80% chance
        return Math.random() < 0.8;
    }

    private void updatePositions() {
        // Check if the lists are null and initialize them if necessary
        if (malePositions == null) {
            malePositions = new ArrayList<>();
        }
        if (femalePositions == null) {
            femalePositions = new ArrayList<>();
        }

        // Clear the lists
        malePositions.clear();
        femalePositions.clear();

        // Update the positions based on the current population
        malePositions.addAll(generateRandomPositions(malePopulation));
        femalePositions.addAll(generateRandomPositions(femalePopulation));
    }

}
