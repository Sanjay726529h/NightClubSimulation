package nightclubsimulation;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.Ellipse2D;
import java.util.List;
import java.util.Properties;
import java.util.Random;
import javax.swing.ImageIcon;

public class NightClubGUI extends JFrame {
    private ImageIcon backgroundImage;
    private ImageIcon maleIcon;
    private ImageIcon femaleIcon;
    private NightClub nightClub;
    private JLabel maleLabel;
    private JLabel femaleLabel;
    private JTextArea simulationDetailsTextArea;
    private SimulationPanel simulationPanel;
    private JSlider maleSlider;
    private JSlider femaleSlider;
    private JSlider speedSlider;

    public static List<Point> malePositions;
    public static List<Point> femalePositions;

    public NightClubGUI(NightClub nightClub) {
        this.nightClub = nightClub;
        initializeUI();
        loadIcons();
    }

    private void loadImage() {
        // Replace "background_image.jpg" with your actual background image file name
        backgroundImage = new ImageIcon("C:\\Users\\Sanjay.Kumar\\Downloads\\finalproject\\NightClub\\src\\main\\java\\nightclubsimulation\\club2.jfif.jpg");
    }

    private void loadIcons() {
        // Replace "male_icon.png" and "female_icon.png" with your actual image file names
        maleIcon = new ImageIcon("C:\\Users\\Sanjay.Kumar\\Downloads\\finalproject\\NightClub\\src\\main\\java\\nightclubsimulation\\icons8-boy-96.png");
        femaleIcon = new ImageIcon("C:\\Users\\Sanjay.Kumar\\Downloads\\finalproject\\NightClub\\src\\main\\java\\nightclubsimulation\\icons8-girl-96.png");
    }

    private void initializeUI() {
        setTitle("Night Club Simulation");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH); // Set to fullscreen

        maleLabel = new JLabel("Males: " + nightClub.getMalePopulation());
        femaleLabel = new JLabel("Females: " + nightClub.getFemalePopulation());

        maleSlider = new JSlider(0, 100, nightClub.getMalePopulation());
        maleSlider.addChangeListener(e -> updateMalePopulation());

        femaleSlider = new JSlider(0, 100, nightClub.getFemalePopulation());
        femaleSlider.addChangeListener(e -> updateFemalePopulation());

        speedSlider = new JSlider(1, 10, 5); // Change the range and initial value as needed
        speedSlider.addChangeListener(e -> updateSimulationSpeed());

        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.X_AXIS));
        topPanel.add(Box.createHorizontalGlue()); // Align components to the center
        topPanel.add(maleLabel);
        topPanel.add(Box.createHorizontalStrut(10)); // Add some spacing
        topPanel.add(maleSlider);
        topPanel.add(Box.createHorizontalStrut(20)); // Add some spacing
        topPanel.add(femaleLabel);
        topPanel.add(Box.createHorizontalStrut(10)); // Add some spacing
        topPanel.add(femaleSlider);
        topPanel.add(Box.createHorizontalStrut(20)); // Add some spacing
        topPanel.add(new JLabel("Simulation Speed:"));
        topPanel.add(speedSlider);
        topPanel.add(Box.createHorizontalGlue()); // Align components to the center

        simulationDetailsTextArea = new JTextArea(10, 50);
        simulationDetailsTextArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(simulationDetailsTextArea);

        simulationPanel = new SimulationPanel();

        JButton startButton = new JButton("Start Simulation");
        startButton.addActionListener(e -> startSimulation());

        // Use BoxLayout for the frame's content pane
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        // Add components to the content pane
        add(topPanel);
        add(scrollPane);
        add(simulationPanel);
        add(startButton);

        setVisible(true);
    }

    private void startSimulation() {
        simulationDetailsTextArea.setText("");
        nightClub.setMalePopulation(maleSlider.getValue());
        nightClub.setFemalePopulation(femaleSlider.getValue());

        // Start a SwingWorker to perform the simulation in the background
        SwingWorker<Void, Void> worker = new SwingWorker<Void, Void>() {
            @Override
            protected Void doInBackground() throws Exception {
                nightClub.startSimulation();
                return null;
            }
        };

        worker.execute();
    }

    private void updateMalePopulation() {
        int value = maleSlider.getValue();
        maleLabel.setText("Males: " + value);
        nightClub.setMalePopulation(value);
    }

    private void updateFemalePopulation() {
        int value = femaleSlider.getValue();
        femaleLabel.setText("Females: " + value);
        nightClub.setFemalePopulation(value);
    }

    private void updateSimulationSpeed() {
        int value = speedSlider.getValue();
        simulationPanel.setSimulationSpeed(value);
    }

    public void updatePopulationLabels() {
        SwingUtilities.invokeLater(() -> {
            maleLabel.setText("Males: " + nightClub.getMalePopulation());
            femaleLabel.setText("Females: " + nightClub.getFemalePopulation());

            String simulationDetails = "\nCurrent Population - Males: " + nightClub.getMalePopulation() +
                    ", Females: " + nightClub.getFemalePopulation() +
                    ", Bouncers: " + nightClub.getBouncerPopulation() + "\n";

            simulationDetails = simulationDetails.concat(NightClub.str1 + "\n");

            simulationDetailsTextArea.append(simulationDetails);

            simulationPanel.repaint();
        });
    }

    private class SimulationPanel extends JPanel {

        // Load the background image
        private Timer timer;
        private Point entrance = new Point(50, 50);
        private Point exit = new Point(50, 300);
        private Point alcoholPoint = new Point(50, 500);
        private int simulationSpeed = 5;

        public SimulationPanel() {

            loadImage();
            timer = new Timer(1000 / simulationSpeed, e -> repaint());
            timer.start();
        }

        public void setSimulationSpeed(int speed) {
            simulationSpeed = speed;
            timer.setDelay(1000 / simulationSpeed);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            // Draw the scaled background image to fit the panel
            if (backgroundImage != null) {
                int panelWidth = getWidth();
                int panelHeight = getHeight();

                // Draw the background image, scaling it to fit the panel
                g.drawImage(backgroundImage.getImage(), 0, 0, panelWidth, panelHeight, null);
            }
            drawMalesAndFemales((Graphics2D) g);
            drawPoints((Graphics2D) g);
        }

        private void drawBackground(Graphics2D g) {
            if (backgroundImage != null) {
                // Draw the background image at (0, 0)
                backgroundImage.paintIcon(this, g, 0, 0);
            }
        }
        private void drawMalesAndFemales(Graphics2D g) {
            Random random = new Random();

            for (int i = 0; i < nightClub.getMalePopulation(); i++) {
                drawPerson(g, maleIcon, random.nextInt(750), random.nextInt(500));
            }

            for (int i = 0; i < nightClub.getFemalePopulation(); i++) {
                drawPerson(g, femaleIcon, random.nextInt(750), random.nextInt(500));
            }
        }

        private void drawPerson(Graphics2D g, ImageIcon icon, int x, int y) {
            icon.paintIcon(this, g, x, y);
        }

        private void drawPoints(Graphics2D g) {
            // Draw Entrance
            g.setColor(Color.ORANGE);
            drawPoint(g, entrance, "Entrance");

            // Draw Exit
            g.setColor(Color.black);
            drawPoint(g, exit, "Exit");

            // Draw Alcohol Point
            g.setColor(Color.yellow);
            drawPoint(g, alcoholPoint, "Alcohol Point");
        }

        private void drawPoint(Graphics2D g, Point point, String label) {
            int size = 30;
            g.fill(new Ellipse2D.Double(point.x - size / 2, point.y - size / 2, size, size));
            g.drawString(label, point.x - size / 2, point.y - size / 2 - 5);
        }

        private List<Point> generateRandomPositions(int count) {
            List<Point> positions = new java.util.ArrayList<>();
            for (int i = 0; i < count; i++) {
                int x = (int) (Math.random() * 800);
                int y = (int) (Math.random() * 600);
                positions.add(new Point(x, y));
            }
            return positions;
        }

        public Dimension getPreferredSize() {
            // Set a smaller preferred height (adjust the value based on your needs)
            int preferredHeight = 500;

            // Set the preferred size based on the background image width and the reduced height
            if (backgroundImage != null) {
                int preferredWidth = backgroundImage.getIconWidth();
                return new Dimension(preferredWidth, preferredHeight);
            } else {
                // Default preferred size
                return new Dimension(800, 600);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Properties config = ConfigReader.getConfig();
            NightClub nightClub = new NightClub(config);
            new NightClubGUI(nightClub);
        });
    }

}
