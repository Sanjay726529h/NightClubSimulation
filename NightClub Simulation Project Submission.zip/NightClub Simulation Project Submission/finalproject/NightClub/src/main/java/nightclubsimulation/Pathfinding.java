// Pathfinding.java
package nightclubsimulation;

import java.awt.Point;
import java.util.List;

public class Pathfinding {
    private SMAStar smaStar;

    public Pathfinding() {
        this.smaStar = new SMAStar();
    }

    public List<Point> findPath(Point start, Point goal) {
        return smaStar.findPath(start, goal);
    }
}
