package nightclubsimulation;

import javax.swing.*;
import java.awt.*;
import java.util.Random;

public class SimpleSimulation extends JFrame {
    private SimulationPanel simulationPanel;

    public SimpleSimulation() {
        setTitle("Simple Simulation");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);

        setLayout(new BorderLayout());

        // Create and add labels for Entrance and Exit at the top
        JLabel entranceLabel = new JLabel("Entrance");
        entranceLabel.setFont(new Font("Arial", Font.BOLD, 16));
        add(entranceLabel, BorderLayout.NORTH);

        // Create and add labels for Exit at the bottom
        JLabel exitLabel = new JLabel("Exit");
        exitLabel.setFont(new Font("Arial", Font.BOLD, 16));
        add(exitLabel, BorderLayout.SOUTH);

        // Create and add the simulation panel to the center
        simulationPanel = new SimulationPanel();
        add(simulationPanel, BorderLayout.CENTER);

        setVisible(true);
    }

    private class SimulationPanel extends JPanel {
        private Timer timer;

        public SimulationPanel() {
            timer = new Timer(1000, e -> repaint());
            timer.start();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            drawMalesAndFemales((Graphics2D) g);
        }

        private void drawMalesAndFemales(Graphics2D g) {
            Random random = new Random();

            int panelWidth = getWidth();
            int panelHeight = getHeight();

            for (int i = 0; i < 5; i++) {
                int xOffset = 90; // Adjust this value to increase the spread

                int xBlue = panelWidth / 2 - 10 - xOffset + random.nextInt(2 * xOffset);
                int y = panelHeight / 2 + random.nextInt(panelHeight / 2);
                drawPerson(g, Color.BLUE, xBlue, y);

                int xPink = panelWidth / 2 - 10 + random.nextInt(2 * xOffset);
                drawPerson(g, Color.PINK, xPink, y);
            }
        }


        private void drawPerson(Graphics2D g, Color color, int x, int y) {
            g.setColor(color);
            g.fillOval(x, y, 20, 20);
        }

        @Override
        public Dimension getPreferredSize() {
            return new Dimension(800, 600);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new SimpleSimulation());
    }
}
